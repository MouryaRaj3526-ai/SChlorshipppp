# College Scholarship Management System

Flask-based scholarship portal for student registration, scholarship applications, and administrator review.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in the `scholarship_portal` folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Start the app:
   `python app.py`
5. Open `http://127.0.0.1:5000`.

The app creates a local `scholarship.db` when run. The existing database was intentionally excluded from this upload because it contains student/admin records and password fields. The application currently contains demo credentials and a demo Flask secret; change these before deploying publicly. Do not use this demo configuration for real student data.
