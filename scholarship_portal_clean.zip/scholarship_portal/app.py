from flask import Flask, request, redirect, session, render_template_string, send_from_directory
import sqlite3
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "college_scholarship_demo"

DB = "scholarship.db"


# =========================================================
# DATABASE
# =========================================================

def db():
    connection = sqlite3.connect(DB)
    connection.row_factory = sqlite3.Row
    return connection


def create_database():

    os.makedirs("uploads", exist_ok=True)

    connection = db()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT UNIQUE,
            password TEXT,
            usn TEXT,
            course TEXT,
            year INTEGER,
            category TEXT,
            percentage REAL,
            income REAL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT UNIQUE,
            password TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scholarships (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            description TEXT,
            categories TEXT,
            min_percentage REAL,
            max_income REAL,
            amount REAL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            scholarship_id INTEGER,
            status TEXT,
            remarks TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            document_type TEXT,
            filename TEXT
        )
    """)

    # Demo admin
    admin = cursor.execute(
        "SELECT * FROM admins WHERE email=?",
        ("admin@college.com",)
    ).fetchone()

    if not admin:
        cursor.execute("""
            INSERT INTO admins
            (name, email, password)
            VALUES (?, ?, ?)
        """, (
            "Scholarship Administrator",
            "admin@college.com",
            "admin123"
        ))

    # Demo student
    student = cursor.execute(
        "SELECT * FROM students WHERE email=?",
        ("student@college.com",)
    ).fetchone()

    if not student:
        cursor.execute("""
            INSERT INTO students
            (
                name, email, password, usn, course,
                year, category, percentage, income
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "Rahul Kumar",
            "student@college.com",
            "student123",
            "4XX21CS001",
            "B.E Computer Science",
            3,
            "SC",
            72,
            200000
        ))

    # Demo scholarships
    count = cursor.execute(
        "SELECT COUNT(*) FROM scholarships"
    ).fetchone()[0]

    if count == 0:

        scholarships = [
            (
                "SC/ST Student Scholarship",
                "Scholarship for eligible SC/ST students.",
                "SC,ST",
                50,
                300000,
                25000
            ),
            (
                "Merit Scholarship",
                "Scholarship for academically excellent students.",
                "SC,ST,OBC,GENERAL",
                80,
                500000,
                30000
            ),
            (
                "Economically Weaker Student Scholarship",
                "Scholarship for students from lower income families.",
                "SC,ST,OBC,GENERAL",
                60,
                250000,
                20000
            )
        ]

        cursor.executemany("""
            INSERT INTO scholarships
            (
                name, description, categories,
                min_percentage, max_income, amount
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, scholarships)

    connection.commit()
    connection.close()


# =========================================================
# STYLE
# =========================================================

STYLE = """
<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    color: #222;
}

.navbar {
    background: #173b7a;
    color: white;
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.navbar h2 {
    margin: 0;
}

.navbar a {
    color: white;
    text-decoration: none;
    background: #dc3545;
    padding: 9px 15px;
    border-radius: 6px;
}

.container {
    width: 92%;
    max-width: 1300px;
    margin: 30px auto;
}

.login-container {
    width: 400px;
    margin: 70px auto;
}

.card {
    background: white;
    padding: 25px;
    margin-bottom: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
}

input,
select,
textarea {
    width: 100%;
    padding: 11px;
    margin: 8px 0 18px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
}

textarea {
    min-height: 100px;
    resize: vertical;
}

button,
.button {
    background: #173b7a;
    color: white;
    padding: 11px 18px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}

.button-green {
    background: #198754;
}

.button-red {
    background: #dc3545;
}

.button-orange {
    background: #f0ad4e;
}

.button-gray {
    background: #6c757d;
}

.stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}

.stat {
    background: white;
    padding: 25px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
}

.stat h1 {
    margin: 5px;
    color: #173b7a;
}

.scholarships {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.scholarship {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
}

.badge {
    padding: 6px 12px;
    border-radius: 20px;
    color: white;
}

.pending {
    background: #f0ad4e;
}

.approved {
    background: #198754;
}

.rejected {
    background: #dc3545;
}

.alert {
    padding: 15px;
    background: #d1e7dd;
    color: #0f5132;
    border-radius: 6px;
    margin-bottom: 20px;
}

.error {
    padding: 15px;
    background: #f8d7da;
    color: #842029;
    border-radius: 6px;
    margin-bottom: 20px;
}

.info {
    padding: 15px;
    background: #cff4fc;
    color: #055160;
    border-radius: 6px;
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

th,
td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

th {
    background: #173b7a;
    color: white;
}

.action-buttons a {
    margin: 3px;
}

.section-title {
    margin-top: 35px;
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

@media(max-width: 800px) {

    .stats,
    .scholarships,
    .form-grid {
        grid-template-columns: 1fr;
    }

    .container {
        width: 95%;
    }

    .login-container {
        width: 90%;
    }

    table {
        display: block;
        overflow-x: auto;
    }
}

</style>
"""


# =========================================================
# LOGIN PAGE
# =========================================================

LOGIN_PAGE = """

<!DOCTYPE html>

<html>

<head>

<title>College Scholarship Portal</title>

{{ style|safe }}

</head>

<body>

<div class="login-container">

<div class="card">

<h1 style="text-align:center;">🎓</h1>

<h2 style="text-align:center;">
College Scholarship Portal
</h2>

<p style="text-align:center;color:#666;">
Scholarship Management System
</p>

{% if error %}

<div class="error">
{{ error }}
</div>

{% endif %}

<form method="POST">

<label>Email</label>

<input
type="email"
name="email"
placeholder="Enter email"
required
>

<label>Password</label>

<input
type="password"
name="password"
placeholder="Enter password"
required
>

<label>Login As</label>

<select name="user_type">

<option value="student">Student</option>

<option value="admin">Administrator</option>

</select>

<button type="submit" style="width:100%;">
LOGIN
</button>

</form>

<hr>

<hr>

<p style="text-align:center;">
New student?
</p>

<a
href="/register"
class="button button-green"
style="width:100%;text-align:center;"
>
CREATE STUDENT ACCOUNT
</a>

<h4>Demo Administrator</h4>

<p>
Email: admin@college.com<br>
Password: admin123
</p>

</div>

</div>

</body>

</html>

"""


# =========================================================
# LOGIN
# =========================================================

@app.route("/", methods=["GET", "POST"])
def login():

    error = None

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]
        user_type = request.form["user_type"]

        connection = db()

        if user_type == "student":

            user = connection.execute("""
                SELECT * FROM students
                WHERE email=? AND password=?
            """, (email, password)).fetchone()

            if user:

                session.clear()
                session["student_id"] = user["id"]
                session["student_name"] = user["name"]

                connection.close()

                return redirect("/student")

        else:

            user = connection.execute("""
                SELECT * FROM admins
                WHERE email=? AND password=?
            """, (email, password)).fetchone()

            if user:

                session.clear()
                session["admin_id"] = user["id"]
                session["admin_name"] = user["name"]

                connection.close()

                return redirect("/admin")

        connection.close()

        error = "Invalid login details."

    return render_template_string(
        LOGIN_PAGE,
        style=STYLE,
        error=error
    )


# =========================================================
# STUDENT DASHBOARD
# =========================================================

@app.route("/student")
def student_dashboard():

    if "student_id" not in session:
        return redirect("/")

    connection = db()

    student = connection.execute("""
        SELECT * FROM students
        WHERE id=?
    """, (session["student_id"],)).fetchone()

    scholarships = connection.execute("""
        SELECT * FROM scholarships
        ORDER BY id DESC
    """).fetchall()

    applications = connection.execute("""
        SELECT
            applications.*,
            scholarships.name
        FROM applications
        JOIN scholarships
        ON applications.scholarship_id = scholarships.id
        WHERE applications.student_id=?
        ORDER BY applications.id DESC
    """, (session["student_id"],)).fetchall()

    connection.close()

    eligible = []

    for scholarship in scholarships:

        categories = [
            x.strip().upper()
            for x in scholarship["categories"].split(",")
        ]

        category_ok = (
            student["category"].upper() in categories
        )

        percentage_ok = (
            student["percentage"] >=
            scholarship["min_percentage"]
        )

        income_ok = (
            student["income"] <=
            scholarship["max_income"]
        )

        if category_ok and percentage_ok and income_ok:
            eligible.append(scholarship)

    html = """

<!DOCTYPE html>

<html>

<head>

<title>Student Dashboard</title>

{{ style|safe }}

</head>

<body>

<div class="navbar">

<h2>🎓 Scholarship Portal</h2>

<div>

Welcome, {{ student.name }}

&nbsp;&nbsp;

<a href="/logout">Logout</a>

</div>

</div>


<div class="container">

{% if message %}

<div class="alert">
{{ message }}
</div>

{% endif %}


<div class="card">

<h2>Student Profile</h2>

<hr>

<div class="form-grid">

<div>

<p><b>Name:</b> {{ student.name }}</p>

<p><b>USN:</b> {{ student.usn }}</p>

<p><b>Course:</b> {{ student.course }}</p>

</div>

<div>

<p><b>Category:</b> {{ student.category }}</p>

<p><b>Percentage:</b> {{ student.percentage }}%</p>

<p>
<b>Family Income:</b>
₹{{ "{:,.0f}".format(student.income) }}
</p>

</div>

</div>

</div>

<div class="card">

<h3>📄 Supporting Documents</h3>

<p>
Upload your caste certificate, income certificate,
marks card and student ID for verification.
</p>

<a
href="/documents"
class="button"
>
MANAGE DOCUMENTS
</a>

</div>
<h2>
🎯 Scholarships You Are Eligible For
</h2>


<div class="scholarships">

{% for scholarship in eligible %}

<div class="scholarship">

<h3>{{ scholarship.name }}</h3>

<p>{{ scholarship.description }}</p>

<hr>

<p>
<b>Category:</b>
{{ scholarship.categories }}
</p>

<p>
<b>Minimum Percentage:</b>
{{ scholarship.min_percentage }}%
</p>

<p>
<b>Maximum Income:</b>
₹{{ "{:,.0f}".format(scholarship.max_income) }}
</p>

<p>
<b>Scholarship Amount:</b>
₹{{ "{:,.0f}".format(scholarship.amount) }}
</p>

<a
class="button button-green"
href="/apply/{{ scholarship.id }}"
>
APPLY NOW
</a>

</div>

{% else %}

<div class="card">

<h3>No eligible scholarships found.</h3>

</div>

{% endfor %}

</div>


<h2 class="section-title">
📋 My Applications
</h2>


<div class="card">

<table>

<tr>

<th>Scholarship</th>

<th>Status</th>

<th>Remarks</th>

</tr>

{% for application in applications %}

<tr>

<td>{{ application.name }}</td>

<td>

{% if application.status == "Approved" %}

<span class="badge approved">
Approved
</span>

{% elif application.status == "Rejected" %}

<span class="badge rejected">
Rejected
</span>

{% else %}

<span class="badge pending">
Pending
</span>

{% endif %}

</td>

<td>
{{ application.remarks or "-" }}
</td>

</tr>

{% else %}

<tr>

<td colspan="3">
No applications yet.
</td>

</tr>

{% endfor %}

</table>

</div>

</div>

</body>

</html>

"""

    return render_template_string(
        html,
        style=STYLE,
        student=student,
        eligible=eligible,
        applications=applications,
        message=request.args.get("message")
    )

@app.route("/documents", methods=["GET", "POST"])
def documents():

    if "student_id" not in session:
        return redirect("/")

    message = None
    error = None

    if request.method == "POST":

        document_type = request.form["document_type"]
        file = request.files.get("document")

        if not file or file.filename == "":
            error = "Please select a document."

        else:

            allowed_extensions = {
                "pdf",
                "jpg",
                "jpeg",
                "png"
            }

            extension = file.filename.rsplit(".", 1)[-1].lower()

            if extension not in allowed_extensions:

                error = "Only PDF, JPG, JPEG and PNG files are allowed."

            else:

                filename = secure_filename(file.filename)

                filename = (
                    str(session["student_id"])
                    + "_"
                    + document_type.replace(" ", "_")
                    + "_"
                    + filename
                )

                upload_path = os.path.join(
                    "uploads",
                    filename
                )

                file.save(upload_path)

                connection = db()

                connection.execute("""
                    INSERT INTO documents
                    (
                        student_id,
                        document_type,
                        filename
                    )
                    VALUES (?, ?, ?)
                """, (
                    session["student_id"],
                    document_type,
                    filename
                ))

                connection.commit()
                connection.close()

                message = "Document uploaded successfully."

    connection = db()

    documents_list = connection.execute("""
        SELECT *
        FROM documents
        WHERE student_id=?
        ORDER BY id DESC
    """, (
        session["student_id"],
    )).fetchall()

    connection.close()

    html = """
<!DOCTYPE html>
<html>
<head>

<title>Student Documents</title>

{{ style|safe }}

</head>

<body>

<div class="navbar">

<h2>📄 Student Documents</h2>

<a href="/student">
Back to Dashboard
</a>

</div>

<div class="container">

<div class="card">

<h2>Upload Supporting Documents</h2>

<p style="color:#666;">
Upload documents required for scholarship verification.
</p>

{% if message %}
<div class="alert">
{{ message }}
</div>
{% endif %}

{% if error %}
<div class="error">
{{ error }}
</div>
{% endif %}

<form method="POST" enctype="multipart/form-data">

<label>Document Type</label>

<select name="document_type" required>

<option value="">
Select Document
</option>

<option value="Caste Certificate">
Caste Certificate
</option>

<option value="Income Certificate">
Income Certificate
</option>

<option value="Marks Card">
Marks Card
</option>

<option value="Student ID">
Student ID
</option>

</select>

<label>Select File</label>

<input
type="file"
name="document"
accept=".pdf,.jpg,.jpeg,.png"
required
>

<button
type="submit"
class="button-green"
>
UPLOAD DOCUMENT
</button>

</form>

</div>

<div class="card">

<h2>📋 My Uploaded Documents</h2>

<table>

<tr>

<th>Document Type</th>

<th>File Name</th>

<th>Action</th>

</tr>

{% for document in documents_list %}

<tr>

<td>
{{ document.document_type }}
</td>

<td>
{{ document.filename }}
</td>

<td>

<a
class="button"
href="/download_document/{{ document.filename }}"
target="_blank"
>
VIEW
</a>

</td>

</tr>

{% else %}

<tr>

<td colspan="3">
No documents uploaded yet.
</td>

</tr>

{% endfor %}

</table>

</div>

</div>

</body>
</html>
"""

    return render_template_string(
        html,
        style=STYLE,
        documents_list=documents_list,
        message=message,
        error=error
    )
@app.route("/download_document/<filename>")
def download_document(filename):

    if "student_id" not in session and "admin_id" not in session:
        return redirect("/")

    return send_from_directory(
        "uploads",
        filename
    )
# =========================================================
# APPLY
# =========================================================

@app.route("/apply/<int:scholarship_id>")
def apply(scholarship_id):

    if "student_id" not in session:
        return redirect("/")

    connection = db()

    student = connection.execute("""
        SELECT * FROM students
        WHERE id=?
    """, (session["student_id"],)).fetchone()

    scholarship = connection.execute("""
        SELECT * FROM scholarships
        WHERE id=?
    """, (scholarship_id,)).fetchone()

    if not scholarship:

        connection.close()

        return redirect(
            "/student?message=Scholarship not found."
        )

    categories = [
        x.strip().upper()
        for x in scholarship["categories"].split(",")
    ]

    eligible = (
        student["category"].upper() in categories
        and student["percentage"] >= scholarship["min_percentage"]
        and student["income"] <= scholarship["max_income"]
    )

    if not eligible:

        connection.close()

        return redirect(
            "/student?message=You are not eligible for this scholarship."
        )

    existing = connection.execute("""
        SELECT * FROM applications
        WHERE student_id=?
        AND scholarship_id=?
    """, (
        session["student_id"],
        scholarship_id
    )).fetchone()

    if existing:

        connection.close()

        return redirect(
            "/student?message=You have already applied for this scholarship."
        )

    connection.execute("""
        INSERT INTO applications
        (
            student_id,
            scholarship_id,
            status,
            remarks
        )
        VALUES (?, ?, ?, ?)
    """, (
        session["student_id"],
        scholarship_id,
        "Pending",
        "Application submitted successfully."
    ))

    connection.commit()
    connection.close()

    return redirect(
        "/student?message=Application submitted successfully!"
    )


# =========================================================
# ADMIN DASHBOARD
# =========================================================

@app.route("/admin")
def admin_dashboard():

    if "admin_id" not in session:
        return redirect("/")

    connection = db()

    students = connection.execute("""
        SELECT COUNT(*) AS count
        FROM students
    """).fetchone()["count"]

    applications_count = connection.execute("""
        SELECT COUNT(*) AS count
        FROM applications
    """).fetchone()["count"]

    pending = connection.execute("""
        SELECT COUNT(*) AS count
        FROM applications
        WHERE status='Pending'
    """).fetchone()["count"]

    approved = connection.execute("""
        SELECT COUNT(*) AS count
        FROM applications
        WHERE status='Approved'
    """).fetchone()["count"]

    scholarships_count = connection.execute("""
        SELECT COUNT(*) AS count
        FROM scholarships
    """).fetchone()["count"]

    applications = connection.execute("""
        SELECT
            applications.id,
            applications.status,
            applications.remarks,
            students.name AS student_name,
            students.usn,
            students.category,
            students.percentage,
            students.income,
            scholarships.name AS scholarship_name
        FROM applications
        JOIN students
        ON applications.student_id = students.id
        JOIN scholarships
        ON applications.scholarship_id = scholarships.id
        ORDER BY applications.id DESC
    """).fetchall()

    scholarships = connection.execute("""
        SELECT * FROM scholarships
        ORDER BY id DESC
    """).fetchall()

    connection.close()

    html = """

<!DOCTYPE html>

<html>

<head>

<title>Administrator Dashboard</title>

{{ style|safe }}

</head>

<body>

<div class="navbar">

<h2>👨‍💼 Scholarship Administration</h2>

<div>

Welcome, {{ session.admin_name }}

&nbsp;&nbsp;

<a href="/logout">Logout</a>

</div>

</div>


<div class="container">

<h1>Administrator Dashboard</h1>


{% if message %}

<div class="alert">
{{ message }}
</div>

{% endif %}


<div class="stats">

<div class="stat">

<h3>Students</h3>

<h1>{{ students }}</h1>

</div>

<div class="stat">

<h3>Applications</h3>

<h1>{{ applications_count }}</h1>

</div>

<div class="stat">

<h3>Pending</h3>

<h1>{{ pending }}</h1>

</div>

<div class="stat">

<h3>Scholarships</h3>

<h1>{{ scholarships_count }}</h1>

</div>

</div>


<!-- =====================================================
ADD SCHOLARSHIP
===================================================== -->

<h2 class="section-title">
➕ Add New Scholarship
</h2>

<div class="card">

<form method="POST" action="/add_scholarship">

<div class="form-grid">

<div>

<label>
Scholarship Name
</label>

<input
type="text"
name="name"
placeholder="Example: Minority Scholarship"
required
>

<label>
Eligible Categories
</label>

<input
type="text"
name="categories"
placeholder="SC,ST,OBC,GENERAL"
required
>

<label>
Minimum Percentage
</label>

<input
type="number"
name="min_percentage"
min="0"
max="100"
step="0.01"
placeholder="60"
required
>

</div>


<div>

<label>
Maximum Family Income
</label>

<input
type="number"
name="max_income"
min="0"
step="1"
placeholder="300000"
required
>

<label>
Scholarship Amount
</label>

<input
type="number"
name="amount"
min="0"
step="1"
placeholder="25000"
required
>

<label>
Description
</label>

<textarea
name="description"
placeholder="Enter scholarship description"
required
></textarea>

</div>

</div>

<button type="submit" class="button-green">
ADD SCHOLARSHIP
</button>

</form>

</div>


<!-- =====================================================
APPLICATIONS
===================================================== -->

<h2 class="section-title">
📋 Scholarship Applications
</h2>

<div class="card">

<table>

<tr>

<th>Student</th>

<th>USN</th>

<th>Category</th>

<th>Percentage</th>

<th>Income</th>

<th>Scholarship</th>

<th>Status</th>

<th>Action</th>

</tr>

{% for application in applications %}

<tr>

<td>
{{ application.student_name }}
</td>

<td>
{{ application.usn }}
</td>

<td>
{{ application.category }}
</td>

<td>
{{ application.percentage }}%
</td>

<td>
₹{{ "{:,.0f}".format(application.income) }}
</td>

<td>
{{ application.scholarship_name }}
</td>

<td>

{% if application.status == "Approved" %}

<span class="badge approved">
Approved
</span>

{% elif application.status == "Rejected" %}

<span class="badge rejected">
Rejected
</span>

{% else %}

<span class="badge pending">
Pending
</span>

{% endif %}

</td>

<td class="action-buttons">

{% if application.status == "Pending" %}

<a
class="button button-green"
href="/approve/{{ application.id }}"
>
Approve
</a>

<a
class="button button-red"
href="/reject/{{ application.id }}"
>
Reject
</a>

{% else %}

Completed

{% endif %}

</td>

</tr>

{% else %}

<tr>

<td colspan="8">
No applications yet.
</td>

</tr>

{% endfor %}

</table>

</div>


<!-- =====================================================
MANAGE SCHOLARSHIPS
===================================================== -->

<h2 class="section-title">
🎓 Manage Scholarships
</h2>

<div class="card">

<table>

<tr>

<th>Name</th>

<th>Categories</th>

<th>Min %</th>

<th>Max Income</th>

<th>Amount</th>

<th>Actions</th>

</tr>

{% for scholarship in scholarships %}

<tr>

<td>
{{ scholarship.name }}
</td>

<td>
{{ scholarship.categories }}
</td>

<td>
{{ scholarship.min_percentage }}%
</td>

<td>
₹{{ "{:,.0f}".format(scholarship.max_income) }}
</td>

<td>
₹{{ "{:,.0f}".format(scholarship.amount) }}
</td>

<td>

<a
class="button button-orange"
href="/edit_scholarship/{{ scholarship.id }}"
>
Edit
</a>

<a
class="button button-red"
href="/delete_scholarship/{{ scholarship.id }}"
onclick="return confirm('Delete this scholarship?');"
>
Delete
</a>

</td>

</tr>

{% endfor %}

</table>

</div>


</div>

</body>

</html>

"""

    return render_template_string(
        html,
        style=STYLE,
        students=students,
        applications_count=applications_count,
        pending=pending,
        approved=approved,
        scholarships_count=scholarships_count,
        applications=applications,
        scholarships=scholarships,
        message=request.args.get("message")
    )


# =========================================================
# ADD SCHOLARSHIP
# =========================================================

@app.route("/add_scholarship", methods=["POST"])
def add_scholarship():

    if "admin_id" not in session:
        return redirect("/")

    name = request.form["name"]
    description = request.form["description"]
    categories = request.form["categories"].upper()
    min_percentage = float(request.form["min_percentage"])
    max_income = float(request.form["max_income"])
    amount = float(request.form["amount"])

    connection = db()

    connection.execute("""
        INSERT INTO scholarships
        (
            name,
            description,
            categories,
            min_percentage,
            max_income,
            amount
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        name,
        description,
        categories,
        min_percentage,
        max_income,
        amount
    ))

    connection.commit()
    connection.close()

    return redirect(
        "/admin?message=Scholarship added successfully!"
    )


# =========================================================
# EDIT SCHOLARSHIP
# =========================================================

@app.route("/edit_scholarship/<int:scholarship_id>", methods=["GET", "POST"])
def edit_scholarship(scholarship_id):

    if "admin_id" not in session:
        return redirect("/")

    connection = db()

    scholarship = connection.execute("""
        SELECT * FROM scholarships
        WHERE id=?
    """, (scholarship_id,)).fetchone()

    if not scholarship:

        connection.close()

        return redirect(
            "/admin?message=Scholarship not found."
        )

    if request.method == "POST":

        name = request.form["name"]
        description = request.form["description"]
        categories = request.form["categories"].upper()
        min_percentage = float(
            request.form["min_percentage"]
        )
        max_income = float(
            request.form["max_income"]
        )
        amount = float(
            request.form["amount"]
        )

        connection.execute("""
            UPDATE scholarships
            SET
                name=?,
                description=?,
                categories=?,
                min_percentage=?,
                max_income=?,
                amount=?
            WHERE id=?
        """, (
            name,
            description,
            categories,
            min_percentage,
            max_income,
            amount,
            scholarship_id
        ))

        connection.commit()
        connection.close()

        return redirect(
            "/admin?message=Scholarship updated successfully!"
        )

    connection.close()

    html = """

<!DOCTYPE html>

<html>

<head>

<title>Edit Scholarship</title>

{{ style|safe }}

</head>

<body>

<div class="navbar">

<h2>🎓 Edit Scholarship</h2>

<a href="/admin">
Back to Admin
</a>

</div>

<div class="container">

<div class="card">

<h2>Edit Scholarship</h2>

<form method="POST">

<label>
Scholarship Name
</label>

<input
type="text"
name="name"
value="{{ scholarship.name }}"
required
>


<label>
Description
</label>

<textarea
name="description"
required
>{{ scholarship.description }}</textarea>


<label>
Eligible Categories
</label>

<input
type="text"
name="categories"
value="{{ scholarship.categories }}"
required
>


<label>
Minimum Percentage
</label>

<input
type="number"
name="min_percentage"
value="{{ scholarship.min_percentage }}"
min="0"
max="100"
step="0.01"
required
>


<label>
Maximum Family Income
</label>

<input
type="number"
name="max_income"
value="{{ scholarship.max_income }}"
min="0"
step="1"
required
>


<label>
Scholarship Amount
</label>

<input
type="number"
name="amount"
value="{{ scholarship.amount }}"
min="0"
step="1"
required
>


<button type="submit" class="button-green">
UPDATE SCHOLARSHIP
</button>

<a
href="/admin"
class="button button-gray"
>
CANCEL
</a>

</form>

</div>

</div>

</body>

</html>

"""

    return render_template_string(
        html,
        style=STYLE,
        scholarship=scholarship
    )


# =========================================================
# DELETE SCHOLARSHIP
# =========================================================

@app.route("/delete_scholarship/<int:scholarship_id>")
def delete_scholarship(scholarship_id):

    if "admin_id" not in session:
        return redirect("/")

    connection = db()

    # Remove applications belonging to this scholarship
    connection.execute("""
        DELETE FROM applications
        WHERE scholarship_id=?
    """, (scholarship_id,))

    # Remove scholarship
    connection.execute("""
        DELETE FROM scholarships
        WHERE id=?
    """, (scholarship_id,))

    connection.commit()
    connection.close()

    return redirect(
        "/admin?message=Scholarship deleted successfully!"
    )


# =========================================================
# APPROVE
# =========================================================

@app.route("/approve/<int:application_id>")
def approve(application_id):

    if "admin_id" not in session:
        return redirect("/")

    connection = db()

    connection.execute("""
        UPDATE applications
        SET
            status='Approved',
            remarks='Application approved by administrator.'
        WHERE id=?
    """, (application_id,))

    connection.commit()
    connection.close()

    return redirect("/admin")


# =========================================================
# REJECT
# =========================================================

@app.route("/reject/<int:application_id>")
def reject(application_id):

    if "admin_id" not in session:
        return redirect("/")

    connection = db()

    connection.execute("""
        UPDATE applications
        SET
            status='Rejected',
            remarks='Application rejected by administrator.'
        WHERE id=?
    """, (application_id,))

    connection.commit()
    connection.close()

    return redirect("/admin")

# =========================================================
# STUDENT REGISTRATION
# =========================================================

@app.route("/register", methods=["GET", "POST"])
def register():

    error = None

    if request.method == "POST":

        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        usn = request.form["usn"]
        course = request.form["course"]
        year = request.form["year"]
        category = request.form["category"]
        percentage = float(request.form["percentage"])
        income = float(request.form["income"])

        connection = db()

        existing = connection.execute("""
            SELECT * FROM students
            WHERE email=? OR usn=?
        """, (email, usn)).fetchone()

        if existing:

            connection.close()

            error = "Email or USN already registered."

        else:

            connection.execute("""
                INSERT INTO students
                (
                    name,
                    email,
                    password,
                    usn,
                    course,
                    year,
                    category,
                    percentage,
                    income
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                name,
                email,
                password,
                usn,
                course,
                year,
                category,
                percentage,
                income
            ))

            connection.commit()
            connection.close()

            return redirect(
                "/?message=Registration successful. Please login."
            )

    html = """

<!DOCTYPE html>

<html>

<head>

<title>Student Registration</title>

{{ style|safe }}

</head>

<body>

<div class="navbar">

<h2>🎓 College Scholarship Portal</h2>

<a href="/">
Back to Login
</a>

</div>


<div class="container">

<div class="card">

<h1>
Student Registration
</h1>

<p style="color:#666;">
Create your student account to check scholarship eligibility
and apply for scholarships.
</p>


{% if error %}

<div class="error">
{{ error }}
</div>

{% endif %}


<form method="POST">


<h3>Personal Information</h3>

<div class="form-grid">

<div>

<label>
Full Name
</label>

<input
type="text"
name="name"
placeholder="Enter full name"
required
>


<label>
Email
</label>

<input
type="email"
name="email"
placeholder="Enter email address"
required
>


<label>
Password
</label>

<input
type="password"
name="password"
placeholder="Create password"
required
>


<label>
USN
</label>

<input
type="text"
name="usn"
placeholder="Example: 4XX21CS001"
required
>

</div>


<div>

<label>
Course
</label>

<input
type="text"
name="course"
placeholder="Example: B.E Computer Science"
required
>


<label>
Year
</label>

<select name="year" required>

<option value="">
Select Year
</option>

<option value="1">
1st Year
</option>

<option value="2">
2nd Year
</option>

<option value="3">
3rd Year
</option>

<option value="4">
4th Year
</option>

</select>


<label>
Category
</label>

<select name="category" required>

<option value="">
Select Category
</option>

<option value="SC">
SC
</option>

<option value="ST">
ST
</option>

<option value="OBC">
OBC
</option>

<option value="GENERAL">
GENERAL
</option>

</select>


<label>
Percentage
</label>

<input
type="number"
name="percentage"
min="0"
max="100"
step="0.01"
placeholder="Example: 75"
required
>


<label>
Annual Family Income
</label>

<input
type="number"
name="income"
min="0"
step="1"
placeholder="Example: 250000"
required
>

</div>

</div>


<br>

<button
type="submit"
class="button-green"
style="width:100%;"
>
CREATE ACCOUNT
</button>


</form>

</div>

</div>

</body>

</html>

"""

    return render_template_string(
        html,
        style=STYLE,
        error=error
    )


# =========================================================
# LOGOUT
# =========================================================

# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")


# =========================================================
# START APPLICATION
# =========================================================

if __name__ == "__main__":

    create_database()

    print("")
    print("==========================================")
    print(" COLLEGE SCHOLARSHIP PORTAL")
    print("==========================================")
    print("")
    print("Open your browser:")
    print("http://127.0.0.1:5000")
    print("")
    print("Student Login:")
    print("student@college.com")
    print("student123")
    print("")
    print("Admin Login:")
    print("admin@college.com")
    print("admin123")
    print("")

    app.run(debug=True)